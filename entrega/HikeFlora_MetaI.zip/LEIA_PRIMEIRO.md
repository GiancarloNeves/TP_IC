# HikeFlora — código e resultados da Meta I

O objetivo deste pacote é reproduzir a classificação de cinco espécies de
plantas e a avaliação no teste independente. As fotografias e os modelos
treinados não estão incluídos. O ficheiro `codigo/selecao_imagens.csv` contém
os 11 000 caminhos escolhidos do Pl@ntNet-300K-v2:
https://zenodo.org/records/10419064.

## Estrutura necessária para executar

Colocar os ficheiros de `codigo/` numa mesma pasta. Nessa pasta, criar
`dataset/train`, `dataset/val` e `dataset/test` com subpastas `0008`, `0172`,
`0200`, `0225` e `0237`. O script `extrair_imagens.py` cria essa estrutura a
partir do arquivo oficial `images.zip` e do manifesto. Depois, usar o Python
3.12 com TensorFlow 2.21 e Pillow.

```powershell
& "$env:USERPROFILE\hfvenv\Scripts\python.exe" -m pip install -r requirements.txt
& "$env:USERPROFILE\hfvenv\Scripts\python.exe" extrair_imagens.py "C:\caminho\images.zip"
& "$env:USERPROFILE\hfvenv\Scripts\python.exe" verificar_dataset.py
& "$env:USERPROFILE\hfvenv\Scripts\python.exe" treinar.py mlp
& "$env:USERPROFILE\hfvenv\Scripts\python.exe" treinar.py cnn
& "$env:USERPROFILE\hfvenv\Scripts\python.exe" treinar_variacoes.py cnn_paragem
& "$env:USERPROFILE\hfvenv\Scripts\python.exe" treinar_variacoes.py cnn_dropout
& "$env:USERPROFILE\hfvenv\Scripts\python.exe" treinar_variacoes.py cnn_aumento
& "$env:USERPROFILE\hfvenv\Scripts\python.exe" avaliar_teste.py
```

`selecionar_imagens.py` só é necessário se se pretender refazer a seleção a
partir do `plantnet300K_metadata.csv` oficial. Ao fazê-lo, confirmar que o
manifesto reproduz os mesmos caminhos antes de substituir os resultados.

Os resultados históricos desta execução estão na pasta `resultados/`. A CNN
com dropout foi escolhida pela menor perda de validação; a avaliação final
comparou `mlp.keras` e `cnn_dropout.keras` nas 1 100 imagens de teste.
